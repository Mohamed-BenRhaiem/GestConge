package services;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import domaine.Conge;
import domaine.Utilisateur;

@Stateless(name = "CG")
public class CongeSession implements CongeSessionLocal, CongeSessionRemote {
    @PersistenceContext
    private EntityManager em;

    @Override
    public Conge addConge(Conge conge) {
        Utilisateur Utilisateur = conge.getEmploye();
        int usedDays = calculateUsedCongeDays(Utilisateur);
        int requestedDays = (int) ((conge.getDateFin().getTime() - conge.getDateDebut().getTime()) / (1000 * 60 * 60 * 24));
        if (usedDays + requestedDays <= Utilisateur.MAX_CONGES_DAYS) {
            em.persist(conge);
            return conge;
        } else {
            throw new IllegalArgumentException("Not enough remaining leave days.");
        }
    }

    @Override
    public Conge getConge(Long id) {
        return em.find(Conge.class, id);
    }

    @Override
    public List<Conge> getAllConges() {
        Query query = em.createQuery("SELECT c FROM Conge c ORDER BY c.dateDebut DESC", Conge.class);
        return query.getResultList();
    }

    @Override
    public Conge updateConge(Conge conge) {
        Conge existingConge = em.find(Conge.class, conge.getId());
        if (existingConge != null) {
            existingConge.setDescription(conge.getDescription());
            existingConge.setDateDebut(conge.getDateDebut());
            existingConge.setDateFin(conge.getDateFin());
            existingConge.setDateRupture(conge.getDateRupture());
            existingConge.setEtat(conge.getEtat());
            return em.merge(existingConge);
        }
        return null;
    }

    @Override
    public void deleteConge(Long id) {
        Conge conge = em.find(Conge.class, id);
        if (conge != null) {
            em.remove(conge);
        }
    }

    @Override
    public List<Conge> getCongesByUserId(long id) {
        TypedQuery<Conge> query = em.createQuery("SELECT c FROM Conge c WHERE c.Utilisateur.id = :userId", Conge.class);
        query.setParameter("userId", id);
        return query.getResultList();
    }

    public int getRemainingCongeDays(Long UtilisateurId) {
        Utilisateur Utilisateur = em.find(Utilisateur.class, UtilisateurId);
        if (Utilisateur != null) {
            return Utilisateur.getRemainingCongeDays();
        } else {
            throw new IllegalArgumentException("Utilisateure not found.");
        }
    }

    private int calculateUsedCongeDays(Utilisateur Utilisateur) {
        return Utilisateur.getConges().stream()
                .mapToInt(conge -> (int) ((conge.getDateFin().getTime() - conge.getDateDebut().getTime()) / (1000 * 60 * 60 * 24)))
                .sum();
    }
}
