package services;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import domaine.Utilisateur;

@Stateless(name = "UT")
public class UtilisateurSession implements UtilisateurSessionLocal, UtilisateurSessionRemote {
	@PersistenceContext
	private EntityManager em;

	@Override
	public Utilisateur addUtilisateur(Utilisateur p) {
		em.persist(p);
		return p;
	}

	@Override
	public Utilisateur getUtilisateur(Long id) {
		Utilisateur p = (Utilisateur) em.find(Utilisateur.class, id);
		return p;
	}

	@Override
	public List<Utilisateur> getAllUtilisateurs() {
		Query sql = em.createQuery("select u from Utilisateur u");
		return sql.getResultList();
	}

	@Override
	public Utilisateur updateUtilisateur(Utilisateur p) {
	    Utilisateur pu = em.find(Utilisateur.class, p.getId());
	    if (pu != null) {
	        pu.setDateEmbauchement(p.getDateEmbauchement());
	        pu.setNom(p.getNom());
	        pu.setPrenom(p.getPrenom());
	        pu.setLogin(p.getLogin());
	        pu.setPassword(p.getPassword());
	        pu.setType(p.getType());
	        pu = em.merge(pu);
	    }
	    return pu;
	}

	@Override
	public void deleteUtilisateur(Long id) {
		Utilisateur pd = (Utilisateur) em.find(Utilisateur.class, id);
		em.remove(pd);
	}

	public Utilisateur getUtilisateurByLogin(String login, String password) {
	    String query = "SELECT u FROM Utilisateur u WHERE u.login = :login AND u.password = :password";
	    TypedQuery<Utilisateur> q = em.createQuery(query, Utilisateur.class);
	    q.setParameter("login", login);
	    q.setParameter("password", password);
	    try {
	        return q.getSingleResult();
	    } catch (NoResultException e) {
	        return null;
	    }
	}

}
