package services;

import java.util.List;
import javax.ejb.Remote;
import domaine.Conge;

@Remote
public interface CongeSessionRemote {
    Conge addConge(Conge conge);
    Conge updateConge(Conge conge);
    void deleteConge(Long id);
    Conge getConge(Long id);
    List<Conge> getCongesByUserId(long id);
    List<Conge> getAllConges();
    int getRemainingCongeDays(Long id);
}
