package services;

import java.util.List;
import javax.ejb.Local;
import domaine.Conge;

@Local
public interface CongeSessionLocal {
    Conge addConge(Conge conge);
    Conge updateConge(Conge conge);
    void deleteConge(Long id);
    Conge getConge(Long id);
    List<Conge> getCongesByUserId(long id);
    List<Conge> getAllConges();
    int getRemainingCongeDays(Long id);
}
