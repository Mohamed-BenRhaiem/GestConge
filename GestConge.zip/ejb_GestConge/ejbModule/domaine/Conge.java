package domaine;

import java.io.Serializable;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import javax.persistence.*;

@Entity
public class Conge implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(length = 255)
    private String description;

    @Temporal(TemporalType.DATE)
    private Date dateDebut;

    @Temporal(TemporalType.DATE)
    private Date dateFin;

    @Temporal(TemporalType.DATE) 
    private Date dateRupture;

    @Column(length = 20)
    private String etat;
    @Transient
    private int nbJoursRest;
    
    @ManyToOne
    @JoinColumn(name = "employe_id", nullable = false)
    private Utilisateur employe;


    public Utilisateur getEmploye() {
		return employe;
	}

	public void setEmploye(Utilisateur employe) {
		this.employe = employe;
	}

	public Conge() {
        super();
        nbJoursRest = 30;
    }
	
	

    public int getNbJoursRest() {
		return nbJoursRest;
	}

	public void setNbJoursRest() {
		 // Calculate the difference between dateFin and dateDebut
        long diffInMillies = Math.abs(dateFin.getTime() - dateDebut.getTime());
        // Convert milliseconds to days
        long diffInDays = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
        // Set the calculated difference as nbJoursRest
        this.nbJoursRest = (int) diffInDays;
	}

	public Conge(String description, Date dateDebut, Date dateFin, Date dateRupture, String etat) {
        super();
        this.description = description;
        this.dateDebut = dateDebut;
        this.dateFin = dateFin;
        this.dateRupture = dateRupture;
        this.etat = etat;
    }

    // Getters and setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getDateDebut() {
        return dateDebut;
    }

    public void setDateDebut(Date dateDebut) {
        this.dateDebut = dateDebut;
    }

    public Date getDateFin() {
        return dateFin;
    }

    public void setDateFin(Date dateFin) {
        this.dateFin = dateFin;
    }

    public Date getDateRupture() {
        return dateRupture;
    }

    public void setDateRupture(Date dateRupture) {
        this.dateRupture = dateRupture;
    }

    public String getEtat() {
        return etat;
    }

    public void setEtat(String etat) {
        this.etat = etat;
    }

    @Override
    public String toString() {
        return "Conge [id=" + id + ", description=" + description + ", dateDebut=" + dateDebut + ", dateFin=" + dateFin
                + ", dateRupture=" + dateRupture + ", etat=" + etat + "]";
    }
}
