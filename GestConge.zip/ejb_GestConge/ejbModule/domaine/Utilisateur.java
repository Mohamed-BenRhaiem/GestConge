package domaine;

import javax.persistence.*;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Entity
public class Utilisateur implements Serializable{

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String code;

    @Column(length = 50, nullable = false)
    private String nom;

    @Column(length = 50, nullable = false)
    private String prenom;

    @Temporal(TemporalType.DATE)
    private Date dateEmbauchement;

    @Column(length = 50, nullable = false)
    private String login;

    @Column(length = 10, nullable = false)
    private String password;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private UserType type;

    @OneToMany(mappedBy = "employe", cascade = CascadeType.ALL, orphanRemoval = true,fetch = FetchType.EAGER)
    private List<Conge> conges;

    public static final int MAX_CONGES_DAYS = 30;

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public Date getDateEmbauchement() {
        return dateEmbauchement;
    }

    public void setDateEmbauchement(Date dateEmbauchement) {
        this.dateEmbauchement = dateEmbauchement;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public UserType getType() {
        return type;
    }

    public void setType(UserType type) {
        this.type = type;
    }

    public List<Conge> getConges() {
        return conges;
    }

    public void setConges(List<Conge> conges) {
        this.conges = conges;
    }

   

    public int calculateUsedCongeDays() {
        return conges.stream()
                .mapToInt(conge -> (int) ((conge.getDateFin().getTime() - conge.getDateDebut().getTime()) / (1000 * 60 * 60 * 24)))
                .sum();
    }

    public int getRemainingCongeDays() {
        return MAX_CONGES_DAYS - calculateUsedCongeDays();
    }
}
