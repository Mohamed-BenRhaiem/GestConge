package domaine;

public enum UserType {
	ADMIN,
	EMPLOYE
}
