package Controller;

import java.io.IOException;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import domaine.Utilisateur;
import services.UtilisateurSessionRemote;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @EJB
    private UtilisateurSessionRemote beanRemote;

    public LoginServlet() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Vous pouvez supprimer cette m�thode doGet() si elle n'est pas n�cessaire
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String login = request.getParameter("login");
        String password = request.getParameter("password");

        try {
            Utilisateur user = beanRemote.getUtilisateurByLogin(login, password);
            if (user != null && user.getPassword().equals(password)) {
                HttpSession session = request.getSession();
                session.setAttribute("user", user);
                response.sendRedirect("home.jsp");
                return;
            } else {
                request.setAttribute("msg", "Login ou mot de passe incorrect");
                request.getRequestDispatcher("login.jsp").forward(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("msg", "Erreur lors de l'authentification");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
}

/*package Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Hashtable;
import java.util.List;

import javax.ejb.EJB;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import domaine.Utilisateur;
import services.UtilisateurSession;
import services.UtilisateurSessionRemote;


@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    Hashtable<String, String> props = null;

    public LoginServlet() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	PrintWriter out = response.getWriter();
    	
    	String l = request.getParameter("login");
  
    	out.println("La valeur du nom est:"+l);
    	
    	String pwd = request.getParameter("password");
   
    	out.println("La valeur du mot de passe est:"+pwd);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	
    	
       try {
    	
           
            String login = request.getParameter("login");
            String password = request.getParameter("password");
            Context ctx = new InitialContext(props);
           	String jndiBeanName = 
           			"ejb:/ejb_GestConge/UT!services.UtilisateurSessionRemote";
           	UtilisateurSessionRemote beanRemote =
           			(UtilisateurSessionRemote) ctx.lookup(jndiBeanName);
         

            Utilisateur user = beanRemote.getUtilisateurByLogin(login, password);            
            if (user != null && user.getPassword().equals(password)) {
                
                HttpSession session = request.getSession();
                session.setAttribute("user", user);
                response.sendRedirect("home.jsp");
            } else {

                request.setAttribute("msg", "Login ou mot de passe incorrect");
                request.getRequestDispatcher("login.jsp").forward(request, response);
            }
        } catch (Exception e) {
        
            e.printStackTrace();
            // G�rer les exceptions, par exemple afficher une erreur g�n�rale
            request.setAttribute("msg", "Erreur lors de l'authentification");
        }
       request.getRequestDispatcher("login.jsp").forward(request, response);
    }
    @Override
	    public void init(ServletConfig config) throws
	    ServletException {
	    // TODO Auto-generated method stub
	    super.init(config);
	    // Charger les proriétés utiles
	    props = new Hashtable<String, String>();
	    // propriétés du fichier "jndi.properties
	    props.put("java.naming.factory.url.pkgs", "org.jboss.ejb.client.naming");
	    props.put("endpoint.name", "client-endpoint");
	    props.put("remote.connectionprovider.create.options.org.xnio.Options.SSL_ENABLED", "false");
	    props.put("remote.connections", "default");
	    props.put("remote.connection.default.host", "127.0.0.1");
	    props.put("remote.connection.default.port", "8080");
	    props.put("remote.connection.default.connect.options.org.xnio.Options.SASL_POLICY_NOANONYMOUS", "false");


}
    
}*/

