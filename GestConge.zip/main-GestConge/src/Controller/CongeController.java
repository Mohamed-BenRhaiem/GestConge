package Controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import domaine.Conge;
import domaine.Utilisateur;
import services.CongeSessionRemote;

@WebServlet("/CongeController")
public class CongeController extends HttpServlet {
    @EJB(lookup = "ejb:/ejb_GestConge/CG!services.CongeSessionRemote")
    private CongeSessionRemote beanRemote;

    private static final long serialVersionUID = 1L;

    public CongeController() {
        super();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Conge> conges = beanRemote.getAllConges();

        Date today = new Date(); // Date actuelle

        for (Conge conge : conges) {
            Date dateDebut = conge.getDateDebut();
            Date dateFin = conge.getDateFin();
            
            if (dateDebut.compareTo(today) <= 0 && dateFin.compareTo(today) >= 0 && "VALIDE".equals(conge.getEtat())) {
                // La date d'aujourd'hui est entre la date de d�but et la date de fin de cong�
                conge.setEtat("EN_COURS");
                // Ajoutez ici le code pour imprimer ce que vous voulez
            }
        }
        request.getServletContext().setAttribute("allConges", conges);
        
        HttpSession session = request.getSession();
        Utilisateur user = (Utilisateur) session.getAttribute("user");
        if (user != null) {
            int remainingCongeDays = user.getRemainingCongeDays();
            session.setAttribute("remainingCongeDays", remainingCongeDays);
        }

        response.sendRedirect("consulterConges.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            if ("add".equals(request.getParameter("action"))) {
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                String description = request.getParameter("demandeDescription");

                Date dateDebutParsed = dateFormat.parse(request.getParameter("dateDebut"));
                Date dateFinParsed = dateFormat.parse(request.getParameter("dateFin"));
                Date dateRuptureParsed = dateFormat.parse(request.getParameter("dateRupture"));
                long diffDays = ChronoUnit.DAYS.between(dateDebutParsed.toInstant(), dateFinParsed.toInstant());

                Utilisateur user = (Utilisateur) request.getSession().getAttribute("user");
                
                int usedCongeDays = user.calculateUsedCongeDays();
                int remainingCongeDays = user.getRemainingCongeDays();

                if (diffDays <= remainingCongeDays) {
                    Conge newConge = new Conge(description, dateDebutParsed, dateFinParsed, dateRuptureParsed, "SOLLICITE");
                    newConge.setEmploye(user);
                    beanRemote.addConge(newConge);
                } else {
                    throw new IllegalArgumentException("Not enough remaining leave days.");
                }
            } else if ("update".equals(request.getParameter("action"))) {
                long congeId = Long.parseLong(request.getParameter("congeId"));
                String etat = request.getParameter("etat");

                Conge conge = beanRemote.getConge(congeId);
                if (conge != null) {
                    if ("VALIDE".equals(etat)) {//t9sed baad myvalidi ??
                        Utilisateur user = conge.getEmploye();
                        LocalDate startDate = convertToLocalDateViaInstant(conge.getDateDebut());
                        LocalDate endDate = convertToLocalDateViaInstant(conge.getDateFin());
                        long diffDays = ChronoUnit.DAYS.between(startDate, endDate);
                         
                        int usedCongeDays = user.calculateUsedCongeDays();
                        int remainingCongeDays = user.getRemainingCongeDays();

                        if (diffDays <= remainingCongeDays) {
                            // Set the leave as validated
                            conge.setEtat(etat);
                            beanRemote.updateConge(conge);
                        } else {
                            throw new IllegalArgumentException("Not enough remaining leave days to validate this leave.");
                        }
                    } else {
                        conge.setEtat(etat);
                        beanRemote.updateConge(conge);
                    }
                }
            }
            else if ("delete".equals(request.getParameter("action"))) {
                long congeId = Long.parseLong(request.getParameter("id"));
                Conge conge = beanRemote.getConge(congeId);
                Date d = conge.getDateDebut();
                beanRemote.deleteConge(congeId);
            }

        } catch (ParseException e) {
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
            String errorMessage = e.getMessage();
            request.setAttribute("errorMessage", errorMessage);
        } catch (Exception e) {
            e.printStackTrace();
            String errorMessage = "An error occurred while processing the cong�. Please try again later.";
            request.setAttribute("errorMessage", errorMessage);
        }

        doGet(request, response);
    }
    private LocalDate convertToLocalDateViaInstant(Date dateToConvert) {
        return new java.sql.Date(dateToConvert.getTime()).toLocalDate();
    }
}
