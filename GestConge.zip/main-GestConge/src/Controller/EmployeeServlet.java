package Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import domaine.Utilisateur;
import services.UtilisateurSessionRemote;

/**
 * Servlet implementation class EmployeeServlet
 */
@WebServlet("/EmployeeServlet")
public class EmployeeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @EJB(lookup = "ejb:/ejb_GestConge/UT!services.UtilisateurSessionRemote")
    private UtilisateurSessionRemote beanRemote;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeServlet() {
        super();
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        
        List<Utilisateur> allUsers = beanRemote.getAllUtilisateurs();
        request.getServletContext().setAttribute("allUsers", allUsers);
        
        response.sendRedirect("Employees.jsp");
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if ("cherche".equals(action)) {
            String idParam = request.getParameter("id");
            if (idParam != null && !idParam.isEmpty()) {
                try {
                    Long id = Long.parseLong(idParam);
                    Utilisateur user = beanRemote.getUtilisateur(id);
                    // Renvoyer uniquement la table des utilisateurs dans la r�ponse
                    response.setContentType("text/html;charset=UTF-8");
                    try (PrintWriter out = response.getWriter()) {
                        request.getRequestDispatcher("userTable.jsp").include(request, response);
                    }
                } catch (NumberFormatException e) {
                    // G�rer l'exception, par exemple en affichant un message d'erreur � l'utilisateur
                    response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                    response.getWriter().write("L'identifiant fourni n'est pas valide.");
                }
            } else {
                // G�rer le cas o� le param�tre "id" est absent ou vide
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                response.getWriter().write("L'identifiant est requis.");
            }
        }
    }
}
